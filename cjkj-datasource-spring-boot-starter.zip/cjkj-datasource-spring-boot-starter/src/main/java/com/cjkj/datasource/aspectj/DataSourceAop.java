package com.cjkj.datasource.aspectj;

import com.cjkj.datasource.dto.TabBaseInfo;
import com.cjkj.datasource.enums.PollMethod;
import com.cjkj.datasource.config.DynamicDataSourceConfig;
import com.cjkj.datasource.properties.DbProperties;
import com.cjkj.datasource.handler.DynamicDataSourceContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Random;

/**
 * @author: RenPL
 * @create 2020/2/12
 * @Description: 数据源切换切面
 **/
@Aspect
@Component
@Slf4j
public class DataSourceAop {

    @Autowired
    private DynamicDataSourceConfig dynamicDataSourceConfig;

    @Autowired
    private DbProperties dbProperties;

    /**
     * 循环轮询index
     */
    int index = 0;

    @Before("execution(* com.cjkj.test.mapper..*.get*(..)) || " +
            "execution(* com.cjkj.test.mapper..*.list*(..)) ||" +
            "execution(* com.cjkj.test.mapper..*.select*(..))")
    public void setReadDataSource() {
        List<TabBaseInfo> readKeys = dynamicDataSourceConfig.getReadKeys();
        DynamicDataSourceContextHolder.setDataSourceType(getSourceKey(readKeys, dbProperties.getPollingWays()));
    }

    @Before("execution(* com.cjkj.test.mapper..*.add*(..)) || " +
            "execution(* com.cjkj.test.mapper..*.update*(..)) ||" +
            "execution(* com.cjkj.test.mapper..*.insert*(..)) ||" +
            "execution(* com.cjkj.test.mapper..*.delete*(..))")
    public void setWriteDataSource() {
        List<TabBaseInfo> writeKeys = dynamicDataSourceConfig.getWriteKeys();
        DynamicDataSourceContextHolder.setDataSourceType(getSourceKey(writeKeys, dbProperties.getPollingWays()));
    }

    /**
     * 功能：
     * 1.指定权重轮询，则当前数据源为权重最高的数据源
     * 2.指定循环轮询，则当前数据源为循环获取配置中数据源列表的数据源
     * 3.指定随机轮询，则当前数据源为随机获取配置中数据源列表的数据源
     *
     * @param sourceKeys
     * @param type：轮询方式【 WEIGHT：权重， RANDOM：随机， type：循环】
     * @return
     */
    public String getSourceKey(List<TabBaseInfo> sourceKeys, String type) {
        if (PollMethod.WEIGHT.name().equals(type)) {
            return getSourceKeyByWeight(sourceKeys);
        } else if (PollMethod.RANDOM.name().equals(type)) {
            TabBaseInfo tabBaseInfo = sourceKeys.get(new Random().nextInt(sourceKeys.size()));
            log.info("随机切换至数据库：{}", tabBaseInfo.getSourceKey());
            return tabBaseInfo.getSourceKey();
        } else if (PollMethod.CYCLE.name().equals(type)) {
            index++;
            index = index % sourceKeys.size();
            log.info("循环切换至数据库：{}", sourceKeys.get(index).getSourceKey());
            return sourceKeys.get(index).getSourceKey();
        }
        return null;
    }

    /**
     * 获取权重最高的数据源对应key
     *
     * @param keys
     * @return
     */
    private String getSourceKeyByWeight(List<TabBaseInfo> keys) {
        int max = 0;
        for (TabBaseInfo tabBaseInfo : keys) {
            if (tabBaseInfo.getWeight() > max) {
                max = tabBaseInfo.getWeight();
            }
        }
        for (TabBaseInfo tabBaseInfo : keys) {
            if (tabBaseInfo.getWeight() == max) {
                log.info("已切换至权重最高的数据库：{}", tabBaseInfo.getSourceKey());
                return tabBaseInfo.getSourceKey();
            }
        }
        return null;
    }
}