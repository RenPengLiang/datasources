package com.cjkj.datasource.enums;

/**
 * @author: RenPL
 * @create 2020/1/2
 * @Description: 轮询方式枚举类
 **/
public enum PollMethod {

    /**
     * 按权重轮询
     */
    WEIGHT,

    /**
     * 按随机轮询
     */
    RANDOM,

    /**
     * 按循环轮询
     */
    CYCLE;
}
