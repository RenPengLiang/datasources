package com.cjkj.datasource.properties;

import com.cjkj.datasource.dto.TabDatasource;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * @description: 数据库基本属性配置
 * @author: RenPL
 * @create: 2019-12-27 10:44
 **/
@Setter
@Getter
@Configuration
@ConfigurationProperties(prefix = "dbs")
public class DbProperties {
    /**
     * 数据源列表
     */
    private List<TabDatasource> baseDbInfoList;

    /**
     * 数据源扫描mapper包名
     */
    private String mapperPackage;

    /**
     * 多数据库操作轮询方式【权重，随机，循环】
     */
    private String pollingWays;
}
