package com.cjkj.datasource.dto;

import lombok.Data;

/**
 * @author: RenPL
 * @create 2020/1/2
 * @Description: 数据源切换对象封装
 **/
@Data
public class TabBaseInfo {

    /**
     * 数据源key
     */
    private String sourceKey;

    /**
     * 数据源权重
     */
    private Integer weight;
}
