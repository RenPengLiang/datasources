package com.cjkj.datasource.config;

import com.cjkj.datasource.dto.TabBaseInfo;
import com.cjkj.datasource.dto.TabDatasource;
import com.cjkj.datasource.properties.DbProperties;
import com.cjkj.datasource.handler.DynamicDataSource;
import com.cjkj.datasource.properties.HikariProperties;
import com.zaxxer.hikari.HikariDataSource;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author: RenPL
 * @create 2020/2/12
 * @Description: 多数据源配置
 **/
@Configuration
@Data
@Slf4j
public class DynamicDataSourceConfig {

    public static final String WRITE = "write";
    public static final String READ = "read";
    public List<TabBaseInfo> writeKeys = new ArrayList<>();
    public List<TabBaseInfo> readKeys = new ArrayList<>();

    /**
     * 实例化多数据源对象
     *
     * @param dbProperties
     * @param hikariProperties
     * @return
     */
    @Bean(name = "dynamicDataSource")
    @Primary
    public DynamicDataSource dataSource(DbProperties dbProperties, HikariProperties hikariProperties) {
        Map<Object, Object> targetDataSources = new HashMap<>();
        List<TabDatasource> baseDbInfoList = dbProperties.getBaseDbInfoList();
        if (baseDbInfoList == null || baseDbInfoList.size() < 1) {
            return null;
        }
        // Map封装数据源实例，结构为{key: 指定的key, value: 数据源实例}
        for (TabDatasource tabDatasource : baseDbInfoList) {
            String type = tabDatasource.getToDataSourceKey();
            HikariDataSource subDataSource = DataSourceBuilder.create().type(HikariDataSource.class).build();
            subDataSource = hikariProperties.dataSource(subDataSource);
            subDataSource.setJdbcUrl(tabDatasource.getJdbcUrl());
            subDataSource.setUsername(tabDatasource.getUsername());
            subDataSource.setPassword(tabDatasource.getPassword());
            subDataSource.setDriverClassName(tabDatasource.getDriverClassName());
            if (type.indexOf(WRITE) != -1) {
                TabBaseInfo tabBaseInfo = new TabBaseInfo();
                tabBaseInfo.setSourceKey(type);
                tabBaseInfo.setWeight(tabDatasource.getWeight());
                writeKeys.add(tabBaseInfo);
                targetDataSources.put(type, subDataSource);
            } else if (type.indexOf(READ) != -1) {
                TabBaseInfo tabBaseInfo = new TabBaseInfo();
                tabBaseInfo.setSourceKey(type);
                tabBaseInfo.setWeight(tabDatasource.getWeight());
                readKeys.add(tabBaseInfo);
                targetDataSources.put(type, subDataSource);
            }
        }
        return new DynamicDataSource((DataSource) targetDataSources.get(writeKeys.get(0).getSourceKey()), targetDataSources);
    }

    /**
     * 实例化事务管理器
     *
     * @param dynamicDataSource
     * @return
     */
    @Bean
    @Primary
    public PlatformTransactionManager dynamicDataSourceTransactionManager(DynamicDataSource dynamicDataSource) {
        return new DataSourceTransactionManager(dynamicDataSource);
    }
}
