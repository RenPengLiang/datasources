package com.cjkj.test.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cjkj.test.entity.SysTwo;

/**
 * @author: RenPL
 * @create 2020/1/2
 * @Description: dao测试类
 **/
public interface SysTwoMapper extends BaseMapper<SysTwo> {

}

