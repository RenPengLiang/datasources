package com.cjkj.test.service;

import com.cjkj.test.entity.SysUserOne;

/**
 * @author: RenPL
 * @create 2020/1/2
 * @Description: service类
 **/
public interface DbService {

    SysUserOne selectUser(long id);

    Object insertTwo();
}
