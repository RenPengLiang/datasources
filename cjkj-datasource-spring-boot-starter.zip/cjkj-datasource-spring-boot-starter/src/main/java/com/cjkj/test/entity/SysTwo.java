package com.cjkj.test.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

/**
 * @author: RenPL
 * @create 2020/1/2
 * @Description: db2 表对象
 **/
@Setter
@Getter
@ToString
@TableName("sys_two")
public class SysTwo implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * two_id
     */
    @TableId
    private Integer twoId;

    /**
     * two_remark
     */
    private String twoRemark;

    public SysTwo() {
    }

}