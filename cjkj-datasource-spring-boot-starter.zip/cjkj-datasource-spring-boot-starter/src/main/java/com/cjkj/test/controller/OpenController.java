package com.cjkj.test.controller;

import com.cjkj.test.service.DbService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author: RenPL
 * @create 2020/1/2
 * @Description: 测试Controller类
 **/
@RestController
public class OpenController {
    @Autowired
    private DbService dbService;

    @GetMapping("/insertTwo")
    public Object insertTwo() {
        return dbService.insertTwo();
    }

    @GetMapping("/selectUser")
    public Object selectUser() {
        return dbService.selectUser(1);
    }

}
