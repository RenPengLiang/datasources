package com.cjkj.test.service.impl;

import com.cjkj.test.entity.SysTwo;
import com.cjkj.test.entity.SysUserOne;
import com.cjkj.test.mapper.SysTwoMapper;
import com.cjkj.test.mapper.SysUserOneMapper;
import com.cjkj.test.service.DbService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Random;

/**
 * @author: RenPL
 * @create 2020/1/2
 * @Description: service实现类
 **/
@Service
public class DbServiceImpl implements DbService {

    @Autowired
    private SysUserOneMapper sysUserOneDao;

    @Autowired
    private SysTwoMapper sysTwoDao;

    @Override
    public SysUserOne selectUser(long id) {
        return sysUserOneDao.selectById(id);
    }

    @Override
    public Object insertTwo() {
        SysTwo sysTwo = new SysTwo();
        sysTwo.setTwoId(new Random().nextInt());
        sysTwo.setTwoRemark("two");
        sysTwoDao.insert(sysTwo);
        return sysTwo;
    }

}
