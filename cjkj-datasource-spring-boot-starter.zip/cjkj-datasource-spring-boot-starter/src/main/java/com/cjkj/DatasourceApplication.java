package com.cjkj;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * @author: RenPL
 * @create 2020/1/2
 * @Description: 项目测试启动类
 **/
@EnableTransactionManagement
@MapperScan("com.cjkj.test.mapper")
@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
public class DatasourceApplication {

    public static void main(String[] args) {
        SpringApplication.run(DatasourceApplication.class, args);
    }

}
